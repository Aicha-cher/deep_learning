from pattern import Checker, Circle, Spectrum
from generator import ImageGenerator

if __name__ == "__main__":
    # exo1
    checker = Checker(250, 25)
    if checker.__dict__:
        gray_checkers = checker.draw()
        checker.show()

    # exo2
    circle = Circle(1024, 200, (512, 256))
    gray_circle = circle.draw()
    circle.show()

    # exo3
    spectrum = Spectrum(500)
    rgb_spectrum = spectrum.draw()
    spectrum.show()

    # exo4
    img = ImageGenerator('./exercise_data', './Labels.json', 10, [50, 50, 3])
    images_batch, label_batch = img.next()
    img.show()

