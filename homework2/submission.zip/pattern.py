
import numpy as np
import matplotlib.pyplot as plt
import logging
logger = logging.getLogger(__name__)


class Checker:

    def __init__(self, resolution: int, tile_size: int):
        if resolution % (2 * tile_size):
            logger.error('/n error the resolution should be a multiple of the tile size')
            return
        self.resolution = resolution
        self.tile_size = tile_size

    def draw(self):
        """
        this method creates the checkerboard pattern of resolution x by x
        and  starting with a black tile
        """

        black_array = np.zeros(self.tile_size)
        white_array = np.ones(self.tile_size)
        nb_repetitions = self.resolution // (2 * self.tile_size)
        core_pattern = np.concatenate([black_array, white_array] * nb_repetitions, axis=0)
        row1_pattern = np.reshape(np.concatenate([core_pattern] * self.tile_size, axis=0), (self.tile_size, self.resolution))

        row2_pattern = 1 - row1_pattern # reverse pattern of row1
        # contact the tow rows patterns
        unit_pattern = np.vstack((row1_pattern, row2_pattern))
        self.output = np.concatenate([unit_pattern] * nb_repetitions, axis=0)
        return self.output.copy()

    def show(self):
        """
        this method plot the checkerboard created by the draw method
        """
        plt.imshow(self.output, cmap='gray')



class Circle:
    def __init__(self, resolution: int, radius: int, position: tuple):
        self.resolution = resolution
        self.radius = radius
        self.position = position

    def draw(self):
        """
        this method to plot a white circle inside of back background of a given resolution
        """
        # create black background of the given resolution
        self.output = np.zeros((self.resolution, self.resolution))
        # get the pixels coordinate
        x, y = np.meshgrid(np.arange(self.resolution), np.arange(self.resolution))
        # set as true the pixels that satisfy the circle formula ((X - Ox) ** 2 + (Y - Oy)**2 <= R**2)
        circle_mask = (x - self.position[0]) ** 2 + (y - self.position[1]) ** 2 <= self.radius ** 2
        # set as white(1) the pixels within the mask
        self.output[circle_mask] = 1
        return self.output.copy()
        # contact the tow rows patterns


    def show(self):
        """
        this method plot the pattern created by the draw method
        """
        plt.imshow(self.output, cmap='gray')


class Spectrum:
    def __init__(self, resolution: int):
        self.resolution = resolution

    def draw(self):
        """
        this method to plot a RGB gradient spectrum in a given resolution square
        """
        # create black background of the given resolution
        self.output = np.zeros((self.resolution, self.resolution, 3))

        # we use the RGB
        # change the intensity for the red channel by  changing the intensity
        # from high on the right to low intensity when we go leftwards
        self.output[:, :, 0] = np.linspace(0, 1, self.resolution)
        # change the intensity for the green channel by  changing the intensity
        # from high on the bottom to low intensity when we go upwards
        self.output[:, :, 1] = np.array([np.linspace(0, 1, self.resolution)]).T
        # change the intensity for the blue channel by  changing the intensity
        # from high on the left to low intensity when we go rightwards
        self.output[:, :, 2] = np.linspace(1, 0, self.resolution)

        return self.output.copy()

    def show(self):
        """
        this method plot the pattern created by the draw method
        """
        plt.imshow(self.output)
